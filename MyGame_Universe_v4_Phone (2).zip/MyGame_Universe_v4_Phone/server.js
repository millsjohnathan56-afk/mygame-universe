const crypto=require("crypto");
const users=new Map();
const games=new Map();
const sessions=new Map();
const saves=new Map();

function send(res,status,data){res.statusCode=status;res.setHeader("Content-Type","application/json");res.end(JSON.stringify(data))}
function body(req){return new Promise((resolve,reject)=>{let s="";req.on("data",c=>{s+=c;if(s.length>100000)reject(new Error("too large"))});req.on("end",()=>{try{resolve(s?JSON.parse(s):{})}catch{reject(new Error("bad json"))}})})}
function token(){return crypto.randomBytes(24).toString("hex")}
function user(req){let t=(req.headers.cookie||"").match(/session=([^;]+)/)?.[1];return sessions.get(t)}
function safeUser(u){return u&&{id:u.id,username:u.username,email:u.email,role:u.role}}
module.exports=async(req,res)=>{
 const url=new URL(req.url,"http://localhost");
 if(req.method==="GET"&&url.pathname==="/api/health")return send(res,200,{ok:true,version:"4.0"});
 if(req.method==="POST"&&url.pathname==="/api/register"){let b=await body(req),name=String(b.username||"").trim(),email=String(b.email||"").trim(),pass=String(b.password||"");if(!/^[A-Za-z0-9_]{3,24}$/.test(name)||pass.length<10)return send(res,400,{error:"Choose a 3-24 character username and a password of at least 10 characters."});if(!email.includes("@")||!email.includes("."))return send(res,400,{error:"Please enter a valid email address."});if([...users.values()].some(u=>u.username.toLowerCase()===name.toLowerCase()))return send(res,409,{error:"Username already exists."});let id=users.size+1,u={id,username:name,email,role:id===1?"admin":"user",passwordHash:crypto.createHash("sha256").update(pass).digest("hex")};users.set(id,u);let s=token();sessions.set(s,id);res.setHeader("Set-Cookie",`session=${s}; HttpOnly; SameSite=Lax; Path=/`);return send(res,200,{user:safeUser(u)})}
 if(req.method==="POST"&&url.pathname==="/api/login"){let b=await body(req),u=[...users.values()].find(x=>x.username===String(b.username||""));if(!u||u.passwordHash!==crypto.createHash("sha256").update(String(b.password||"")).digest("hex"))return send(res,401,{error:"Invalid username or password."});let s=token();sessions.set(s,u.id);res.setHeader("Set-Cookie",`session=${s}; HttpOnly; SameSite=Lax; Path=/`);return send(res,200,{user:safeUser(u)})}
 if(req.method==="GET"&&url.pathname==="/api/me"){let id=user(req);return send(res,200,{user:safeUser(users.get(id))})}
 if(req.method==="GET"&&url.pathname==="/api/games"){return send(res,200,{games:[...games.values()].filter(g=>g.public)})}
 if(req.method==="POST"&&url.pathname==="/api/games"){let id=user(req);if(!id)return send(res,401,{error:"Please log in."});let b=await body(req),g={id:games.size+1,name:String(b.name||"").slice(0,60),description:String(b.description||"").slice(0,240),owner:id,public:true};if(!g.name)return send(res,400,{error:"Game name required."});games.set(g.id,g);return send(res,200,{game:g})}
 if(req.method==="PUT"&&url.pathname.startsWith("/api/saves/")){let id=user(req);if(!id)return send(res,401,{error:"Please log in."});let gid=url.pathname.split("/").pop(),b=await body(req);saves.set(`${id}:${gid}`,b);return send(res,200,{ok:true})}
 if(req.method==="GET"&&url.pathname.startsWith("/api/saves/")){let id=user(req);if(!id)return send(res,401,{error:"Please log in."});let gid=url.pathname.split("/").pop();return send(res,200,{data:saves.get(`${id}:${gid}`)||null})}
 if(req.method==="POST"&&url.pathname==="/api/recover"){return send(res,200,{message:"If that email is registered, recovery instructions will be sent."})}
 return send(res,404,{error:"Not found"});
};